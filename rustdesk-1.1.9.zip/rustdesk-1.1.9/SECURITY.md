# Security Policy

## Supported Versions

| Version   | Supported          |
| --------- | ------------------ |
| 1.1.x     | :white_check_mark: |
| 1.x       | :white_check_mark: |
| Below 1.0 | :x:                |

## Reporting a Vulnerability

Here we should write what to do in case of a security vulnerability
